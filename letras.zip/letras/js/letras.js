//Sección del buscador//
var consulta = $("#searchtable").DataTable();

$("#inputbusqueda").keyup(function(){
    consulta.search($(this).val()).draw();

    $("header").css({
        "height": "100vh",
        "background": "rgba(0, 0, 0, 0.5)"
    })

    if($("#inputbusqueda").val()== ""){
        $("header").css({
            "height": "auto",
            "background": "none"
        })

        $("#search").hide();
    } else{
        $("#search").fadeIn("fast");
    }
});
//Sección del carousel//
window.addEventListener('load', function() {
    new Glider(document.querySelector('.carousel_lista'),{
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: '.carousel_indicadores',
        arrows: {
            prev: '.carousel_anterior',
            next: '.carousel_siguiente'
        },
        responsive: [
            {
                breakpoint: 400,
                settings: {
                  slidesToShow: 2,
                  slidesToScroll: 1
                }
            },{
                breakpoint: 600,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 2
                }
            },{
              breakpoint: 800,
              settings: {
                slidesToShow: 4,
                slidesToScroll: 3
              }
            },{
              breakpoint: 1000,
              settings: {
                slidesToShow: 5,
                slidesToScroll: 4
              }
            },{
              breakpoint: 1200,
              settings: {
                slidesToShow: 6,
                slidesToScroll: 5
              }
            }
          ]
    });
});